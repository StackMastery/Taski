export default function Br() {
  return (
    <>
      <br className="hidden sm:block" />
    </>
  );
}
